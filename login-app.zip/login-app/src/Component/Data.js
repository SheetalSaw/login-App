const data = [
    {
      'Gadgets': [
        {
          'name': 'iphone',
          'image': '/assets/images/iphone.png',
          
        },
        {
          'name': 'samsung',
          'image': '/assets/images/samsung.jpg',
          
        },
        
      ]
    },
    {
      'Books': [
        {
          'name': 'Fiction',
          'image': '/assets/images/book-1.jpg',
          
        },
        {
          'name': 'education',
          'image': '/assets/images/book-2.jpg',
          
        },
        
      ]
    }
  ]

  export default data;



  
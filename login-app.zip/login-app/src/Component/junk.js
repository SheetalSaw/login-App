export const data = [
    { name: "sheetal", email: "sawkaresheetal18@gmail.com", city: "bhusawal" },
    { name: "sheetalr", email: "sawkaresheetal18fff@gmail.com", city: "bhusawal" },
    { name: "sheetal", email: "sawkaresheetal18ggg@gmail.com", city: "bhusawal" },
];




import React from 'react'

function UpdateProfile() {
  return (
    <div>UpdateProfile</div>
  )
}

export default UpdateProfile